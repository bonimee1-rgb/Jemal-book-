# Jemal Books and Hadith App

A responsive Progressive Web App (PWA) starter for an Islamic digital library.

## Included
- Amharic-first responsive interface
- Categories for Quran, Tafsir, Hadith, Fiqh, Aqidah, Seerah and Arabic
- Search, book reader shell, saved-book list
- Admin form to add book metadata and a small PDF (local device only)
- Basic service-worker caching for offline app-shell access
- Install prompt where supported

## Important content notice
This starter does **not** contain thousands of pages or complete verified religious texts. Sample catalog entries are placeholders. Import only texts whose accuracy and redistribution rights have been verified. Hadith numbering, grading, translations and scholarly explanations should be checked against reliable editions and qualified reviewers.

## Run locally
Serve this folder over HTTP (service workers do not work from a plain `file://` URL). For example:
`python -m http.server 8000`
Then open `http://localhost:8000`.

## Deploy
Upload the project to a GitHub repository and import that repository into Vercel. No build command is required; set the output/root directory to this project folder.

## Production requirements
For a shared library with thousands of books:
- Database: Supabase or another managed database
- Object storage: Supabase Storage or compatible storage for PDFs
- Authentication and admin roles
- Server-side search/indexing
- CDN and access controls
- Backup, source metadata, licenses and editorial review

The current PDF upload is local-only and limited to 15 MB. It is not a multi-user cloud upload.
